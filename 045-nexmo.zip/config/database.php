<?php
/**
 * Created by PhpStorm.
 * User: Tai
 * Date: 9/27/2020
 * Time: 1:23 PM
 */

define('DB_HOST', 'localhost');
define('DB_DATABASE', '045starpromo_prank');
define('DB_USER', 'root');
define('DB_PASS', '');

